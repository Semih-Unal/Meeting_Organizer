﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MO.BLL
{
    using DAL;
    public class ParticipantService
    {
        MeetingContext db = new MeetingContext();

        public List<Participant> getAllParticipants()
        {
            return db.Participants.ToList();
        }

        public List<Participant> getAllParticipantsByMeetingID(int ID)
        {
            return db.Participants.Where(p=>p.bridgeTable.Any(x=>x.MeetingID==ID)).ToList();
        }

        public Participant getParticipantById(int ID)
        {
            return db.Participants.FirstOrDefault(p=>p.ParticipantID == ID);
        }

        public bool InsertParticipant(Participant newparticipant, int MeetingId)
        {
            bool result = false;
            try
            {
                db.Participants.Add(newparticipant);
                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {
                
            }
            return result;
        }
        public bool DeleteParticipant(int Id)
        {
            bool result = false;
            try
            {
                var remove = db.Participants.Find(Id);
                db.Participants.Remove(remove);
                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }
            return result;
        }
        public bool UpdateParticipant(Participant updateParticipant, int MeetingId)
        {
            bool result = false;
            try
            {
                var item = db.Participants.Find(updateParticipant.ParticipantID);
                item.FullName = updateParticipant.FullName;
                item.PhotoPath = updateParticipant.PhotoPath;
                item.Position = updateParticipant.Position;
                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }
            return result;
        }
    }
}
