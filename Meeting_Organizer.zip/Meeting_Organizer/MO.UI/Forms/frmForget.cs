﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MO.BLL;

namespace MO.UI.Forms
{
    public partial class frmForget : Form
    {
        UserService us = new UserService();
        public frmForget()
        {
            InitializeComponent();
        }
        // ChangePassword Button
        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (us.userChangePassword(txtFullName.Text,txtUserName.Text, txtNewPassword.Text) == true)
            {
                Forms.frmLogin frm = new Forms.frmLogin();

                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı Adınızı veya Adı Soyadınızı Kontrol Ediniz!!");
            }
        }
        // Home Button
        private void btnHome_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();

            frmHome.Show();
            this.Hide();
        }
        // Close Button
        private void btnClose_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();

            frmHome.Show();
            this.Hide();
        }
    }
}
