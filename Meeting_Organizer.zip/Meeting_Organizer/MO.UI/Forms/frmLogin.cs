﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MO.BLL;

namespace MO.UI.Forms
{
    public partial class frmLogin : Form
    {
        UserService us = new UserService();

        public frmLogin()
        {
            InitializeComponent();
        }
        // Login Button
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (us.userLogin(txtUserName.Text,txtPassword.Text) == true)
            {
                Forms.frmMeeting frm = new Forms.frmMeeting();

                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı Adı veya Şifre Hatalı!!");
            }
        }
        // Home Button
        private void btnHome_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();

            frmHome.Show();
            this.Hide();
        }
        // Close Button
        private void btnClose_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();

            frmHome.Show();
            this.Hide();
        }
        // LinkLabel
        private void linkLabelForget_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Forms.frmForget frm = new frmForget();
            frm.Show();
            this.Hide();
        }
    }
}
