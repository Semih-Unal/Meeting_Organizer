﻿namespace MO.UI.Forms
{
    partial class frmMeeting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblLoginTime = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dGwMeetings = new System.Windows.Forms.DataGridView();
            this.mtxtEndTime = new System.Windows.Forms.MaskedTextBox();
            this.mtxtStartTime = new System.Windows.Forms.MaskedTextBox();
            this.dTpDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMeetingName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtMeetingSubject = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnFieldClear = new System.Windows.Forms.Button();
            this.dGwParticipants = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSelectPhoto = new System.Windows.Forms.Button();
            this.pbPhoto = new System.Windows.Forms.PictureBox();
            this.btnAddMeeting = new System.Windows.Forms.Button();
            this.btnParticipantDelete = new System.Windows.Forms.Button();
            this.btnParticipantUpdate = new System.Windows.Forms.Button();
            this.btnParticipantAdd = new System.Windows.Forms.Button();
            this.txtPhotoPath = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tmr = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwMeetings)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwParticipants)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.lblLoginTime);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(946, 35);
            this.panel1.TabIndex = 14;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackgroundImage = global::MO.UI.Properties.Resources.cancel;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Location = new System.Drawing.Point(917, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(24, 24);
            this.btnClose.TabIndex = 4;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblLoginTime
            // 
            this.lblLoginTime.AutoSize = true;
            this.lblLoginTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLoginTime.ForeColor = System.Drawing.Color.White;
            this.lblLoginTime.Location = new System.Drawing.Point(12, 9);
            this.lblLoginTime.Name = "lblLoginTime";
            this.lblLoginTime.Size = new System.Drawing.Size(0, 20);
            this.lblLoginTime.TabIndex = 47;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 526);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(946, 35);
            this.panel2.TabIndex = 15;
            // 
            // btnHome
            // 
            this.btnHome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHome.BackgroundImage = global::MO.UI.Properties.Resources.home;
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Location = new System.Drawing.Point(891, 41);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(43, 35);
            this.btnHome.TabIndex = 25;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(27, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(173, 25);
            this.label9.TabIndex = 26;
            this.label9.Text = "Meeting Organizer";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabControl1.Location = new System.Drawing.Point(0, 92);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(946, 434);
            this.tabControl1.TabIndex = 27;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.dGwMeetings);
            this.tabPage1.Controls.Add(this.mtxtEndTime);
            this.tabPage1.Controls.Add(this.mtxtStartTime);
            this.tabPage1.Controls.Add(this.dTpDate);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtMeetingName);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnUpdate);
            this.tabPage1.Controls.Add(this.btnClear);
            this.tabPage1.Controls.Add(this.btnDelete);
            this.tabPage1.Controls.Add(this.txtMeetingSubject);
            this.tabPage1.Controls.Add(this.btnAdd);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(938, 401);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Toplantı Ekle/Güncelle/Sil";
            // 
            // dGwMeetings
            // 
            this.dGwMeetings.AllowUserToAddRows = false;
            this.dGwMeetings.AllowUserToOrderColumns = true;
            this.dGwMeetings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGwMeetings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwMeetings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dGwMeetings.Location = new System.Drawing.Point(3, 192);
            this.dGwMeetings.MultiSelect = false;
            this.dGwMeetings.Name = "dGwMeetings";
            this.dGwMeetings.ReadOnly = true;
            this.dGwMeetings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwMeetings.Size = new System.Drawing.Size(932, 206);
            this.dGwMeetings.TabIndex = 39;
            this.dGwMeetings.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwMeetings_CellClick);
            // 
            // mtxtEndTime
            // 
            this.mtxtEndTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtEndTime.Location = new System.Drawing.Point(167, 85);
            this.mtxtEndTime.Mask = "00:00";
            this.mtxtEndTime.Name = "mtxtEndTime";
            this.mtxtEndTime.Size = new System.Drawing.Size(54, 26);
            this.mtxtEndTime.TabIndex = 27;
            this.mtxtEndTime.ValidatingType = typeof(System.DateTime);
            // 
            // mtxtStartTime
            // 
            this.mtxtStartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtStartTime.Location = new System.Drawing.Point(167, 53);
            this.mtxtStartTime.Mask = "00:00";
            this.mtxtStartTime.Name = "mtxtStartTime";
            this.mtxtStartTime.Size = new System.Drawing.Size(54, 26);
            this.mtxtStartTime.TabIndex = 26;
            this.mtxtStartTime.ValidatingType = typeof(System.DateTime);
            // 
            // dTpDate
            // 
            this.dTpDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dTpDate.Location = new System.Drawing.Point(168, 22);
            this.dTpDate.Name = "dTpDate";
            this.dTpDate.Size = new System.Drawing.Size(217, 23);
            this.dTpDate.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(27, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Bitiş Saati";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(27, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Başlangıç Saati";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(27, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "Tarih";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(417, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 20);
            this.label2.TabIndex = 37;
            this.label2.Text = "Konusu";
            // 
            // txtMeetingName
            // 
            this.txtMeetingName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtMeetingName.Location = new System.Drawing.Point(558, 25);
            this.txtMeetingName.Name = "txtMeetingName";
            this.txtMeetingName.Size = new System.Drawing.Size(217, 26);
            this.txtMeetingName.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(417, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 38;
            this.label1.Text = "Toplantı Adı";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(421, 155);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(170, 31);
            this.btnUpdate.TabIndex = 31;
            this.btnUpdate.Text = "Toplantıyı Güncelle";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(744, 155);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(141, 31);
            this.btnClear.TabIndex = 32;
            this.btnClear.Text = "Temizle";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(597, 155);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(141, 31);
            this.btnDelete.TabIndex = 32;
            this.btnDelete.Text = "Toplantıyı Sil";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtMeetingSubject
            // 
            this.txtMeetingSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtMeetingSubject.Location = new System.Drawing.Point(557, 57);
            this.txtMeetingSubject.Multiline = true;
            this.txtMeetingSubject.Name = "txtMeetingSubject";
            this.txtMeetingSubject.Size = new System.Drawing.Size(218, 59);
            this.txtMeetingSubject.TabIndex = 29;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(271, 155);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(141, 31);
            this.btnAdd.TabIndex = 30;
            this.btnAdd.Text = "Toplantı Ekle";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.btnFieldClear);
            this.tabPage2.Controls.Add(this.dGwParticipants);
            this.tabPage2.Controls.Add(this.btnSelectPhoto);
            this.tabPage2.Controls.Add(this.pbPhoto);
            this.tabPage2.Controls.Add(this.btnAddMeeting);
            this.tabPage2.Controls.Add(this.btnParticipantDelete);
            this.tabPage2.Controls.Add(this.btnParticipantUpdate);
            this.tabPage2.Controls.Add(this.btnParticipantAdd);
            this.tabPage2.Controls.Add(this.txtPhotoPath);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtPosition);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtFullName);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(938, 401);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Katılımcı Ekle";
            // 
            // btnFieldClear
            // 
            this.btnFieldClear.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnFieldClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFieldClear.FlatAppearance.BorderSize = 0;
            this.btnFieldClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFieldClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFieldClear.ForeColor = System.Drawing.Color.White;
            this.btnFieldClear.Location = new System.Drawing.Point(434, 148);
            this.btnFieldClear.Name = "btnFieldClear";
            this.btnFieldClear.Size = new System.Drawing.Size(92, 31);
            this.btnFieldClear.TabIndex = 51;
            this.btnFieldClear.Text = "Temizle";
            this.btnFieldClear.UseVisualStyleBackColor = false;
            this.btnFieldClear.Click += new System.EventHandler(this.btnFieldClear_Click);
            // 
            // dGwParticipants
            // 
            this.dGwParticipants.AllowUserToAddRows = false;
            this.dGwParticipants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwParticipants.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dGwParticipants.Location = new System.Drawing.Point(532, 26);
            this.dGwParticipants.Name = "dGwParticipants";
            this.dGwParticipants.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwParticipants.Size = new System.Drawing.Size(387, 233);
            this.dGwParticipants.TabIndex = 50;
            this.dGwParticipants.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwParticipants_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Seç";
            this.Column1.Name = "Column1";
            this.Column1.Width = 50;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Ad Soyad";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Pozisyon";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Resim";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "ID";
            this.Column5.Name = "Column5";
            // 
            // btnSelectPhoto
            // 
            this.btnSelectPhoto.Location = new System.Drawing.Point(467, 99);
            this.btnSelectPhoto.Name = "btnSelectPhoto";
            this.btnSelectPhoto.Size = new System.Drawing.Size(52, 26);
            this.btnSelectPhoto.TabIndex = 49;
            this.btnSelectPhoto.Text = "---";
            this.btnSelectPhoto.UseVisualStyleBackColor = true;
            this.btnSelectPhoto.Click += new System.EventHandler(this.btnSelectPhoto_Click);
            // 
            // pbPhoto
            // 
            this.pbPhoto.BackColor = System.Drawing.Color.White;
            this.pbPhoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbPhoto.Location = new System.Drawing.Point(28, 23);
            this.pbPhoto.Name = "pbPhoto";
            this.pbPhoto.Size = new System.Drawing.Size(104, 102);
            this.pbPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPhoto.TabIndex = 48;
            this.pbPhoto.TabStop = false;
            // 
            // btnAddMeeting
            // 
            this.btnAddMeeting.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAddMeeting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddMeeting.FlatAppearance.BorderSize = 0;
            this.btnAddMeeting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddMeeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAddMeeting.ForeColor = System.Drawing.Color.White;
            this.btnAddMeeting.Location = new System.Drawing.Point(614, 293);
            this.btnAddMeeting.Name = "btnAddMeeting";
            this.btnAddMeeting.Size = new System.Drawing.Size(258, 31);
            this.btnAddMeeting.TabIndex = 44;
            this.btnAddMeeting.Text = "Seçili Olanları Toplantıya Ekle";
            this.btnAddMeeting.UseVisualStyleBackColor = false;
            this.btnAddMeeting.Click += new System.EventHandler(this.btnAddMeeting_Click);
            // 
            // btnParticipantDelete
            // 
            this.btnParticipantDelete.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnParticipantDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnParticipantDelete.FlatAppearance.BorderSize = 0;
            this.btnParticipantDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParticipantDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnParticipantDelete.ForeColor = System.Drawing.Color.White;
            this.btnParticipantDelete.Location = new System.Drawing.Point(320, 148);
            this.btnParticipantDelete.Name = "btnParticipantDelete";
            this.btnParticipantDelete.Size = new System.Drawing.Size(108, 31);
            this.btnParticipantDelete.TabIndex = 44;
            this.btnParticipantDelete.Text = "Katılımcı Sil";
            this.btnParticipantDelete.UseVisualStyleBackColor = false;
            this.btnParticipantDelete.Click += new System.EventHandler(this.btnParticipantDelete_Click);
            // 
            // btnParticipantUpdate
            // 
            this.btnParticipantUpdate.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnParticipantUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnParticipantUpdate.FlatAppearance.BorderSize = 0;
            this.btnParticipantUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParticipantUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnParticipantUpdate.ForeColor = System.Drawing.Color.White;
            this.btnParticipantUpdate.Location = new System.Drawing.Point(173, 148);
            this.btnParticipantUpdate.Name = "btnParticipantUpdate";
            this.btnParticipantUpdate.Size = new System.Drawing.Size(141, 31);
            this.btnParticipantUpdate.TabIndex = 44;
            this.btnParticipantUpdate.Text = "Katılımcı Güncelle";
            this.btnParticipantUpdate.UseVisualStyleBackColor = false;
            this.btnParticipantUpdate.Click += new System.EventHandler(this.btnParticipantUpdate_Click);
            // 
            // btnParticipantAdd
            // 
            this.btnParticipantAdd.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnParticipantAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnParticipantAdd.FlatAppearance.BorderSize = 0;
            this.btnParticipantAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParticipantAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnParticipantAdd.ForeColor = System.Drawing.Color.White;
            this.btnParticipantAdd.Location = new System.Drawing.Point(26, 148);
            this.btnParticipantAdd.Name = "btnParticipantAdd";
            this.btnParticipantAdd.Size = new System.Drawing.Size(141, 31);
            this.btnParticipantAdd.TabIndex = 44;
            this.btnParticipantAdd.Text = "Katılımcı Ekle";
            this.btnParticipantAdd.UseVisualStyleBackColor = false;
            this.btnParticipantAdd.Click += new System.EventHandler(this.btnParticipantAdd_Click);
            // 
            // txtPhotoPath
            // 
            this.txtPhotoPath.Enabled = false;
            this.txtPhotoPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPhotoPath.Location = new System.Drawing.Point(263, 99);
            this.txtPhotoPath.Name = "txtPhotoPath";
            this.txtPhotoPath.Size = new System.Drawing.Size(198, 26);
            this.txtPhotoPath.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(158, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 45;
            this.label8.Text = "Resmi";
            // 
            // txtPosition
            // 
            this.txtPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPosition.Location = new System.Drawing.Point(263, 58);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(198, 26);
            this.txtPosition.TabIndex = 42;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(158, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 20);
            this.label7.TabIndex = 46;
            this.label7.Text = "Pozisyonu";
            // 
            // txtFullName
            // 
            this.txtFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtFullName.Location = new System.Drawing.Point(263, 23);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(198, 26);
            this.txtFullName.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(158, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Adı Soyadı";
            // 
            // tmr
            // 
            this.tmr.Interval = 1000;
            this.tmr.Tick += new System.EventHandler(this.tmr_Tick);
            // 
            // frmMeeting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 561);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMeeting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Toplantı Ekle/Güncelle/Sil";
            this.Load += new System.EventHandler(this.frmMeeting_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwMeetings)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwParticipants)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dGwMeetings;
        private System.Windows.Forms.MaskedTextBox mtxtEndTime;
        private System.Windows.Forms.MaskedTextBox mtxtStartTime;
        private System.Windows.Forms.DateTimePicker dTpDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMeetingName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtMeetingSubject;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.PictureBox pbPhoto;
        private System.Windows.Forms.Button btnParticipantAdd;
        private System.Windows.Forms.TextBox txtPhotoPath;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnParticipantDelete;
        private System.Windows.Forms.Button btnParticipantUpdate;
        private System.Windows.Forms.Button btnSelectPhoto;
        private System.Windows.Forms.Button btnAddMeeting;
        private System.Windows.Forms.DataGridView dGwParticipants;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label lblLoginTime;
        private System.Windows.Forms.Timer tmr;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnFieldClear;
    }
}