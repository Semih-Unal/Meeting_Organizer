﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MO.BLL
{
    using DAL;
    
    public class UserService
    {
        MeetingContext db = new MeetingContext();

        public bool userLogin(string username, string password)
        {
            bool result = false;
            try
            {
                var user = db.Users.Where(u => u.UserName == username && u.Password == password).FirstOrDefault();

                result = user != null ? true : false;
            }
            catch 
            {
                
            }
            return result;
        }
        public bool userChangePassword(string fullname,string username, string newpassword)
        {
            bool result = false;
            try
            {
                var user = db.Users.Where(u => u.UserName == username && u.FullName == fullname).FirstOrDefault();
                if (user!=null)
                {
                    user.Password = newpassword;
                }
                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }
            return result;
        }
    }
}
