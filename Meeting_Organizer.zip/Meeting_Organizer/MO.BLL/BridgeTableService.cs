﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MO.DAL;

namespace MO.BLL
{
    public class BridgeTableService
    {
        MeetingContext db = new MeetingContext();

        public bool InsertBridge(BridgeTable bridge)
        {
            bool result = false;
            try
            {
                db.BridgeTables.Add(bridge);
                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }
            return result;
        }
    }
}
