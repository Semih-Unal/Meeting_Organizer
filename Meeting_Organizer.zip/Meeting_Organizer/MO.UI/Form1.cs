﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MO.DAL;
using MO.BLL;

namespace MO.UI
{
    public partial class Form1 : Form
    {
        MeetingService ms = new MeetingService();
        ParticipantService ps = new ParticipantService();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tmr.Start();
        }
        // Login Button
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Forms.frmLogin frm = new Forms.frmLogin();

            frm.Show();
            this.Hide();
        }
        // Close Button
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // DateTimePicker ValuChange Event
        private void dTpDate_ValueChanged(object sender, EventArgs e)
        {
            cbMeeting.DataSource = null;
            cbMeeting.Text = "-Seçiniz-";
            var list = ms.getMeetingsByDate(dTpDate.Value);
            if (list.Count != 0)
            {
                cbMeeting.DataSource = list;
                cbMeeting.DisplayMember = "Title";
                cbMeeting.ValueMember = "MeetingID";
            }
            else
            {
                MessageBox.Show("Seçili Tarihte Toplantı Bulunmamaktadır!");
            }

        }
        // Combobox SelectionCommited Event
        private void cbMeeting_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Meeting selectedMeeting = cbMeeting.SelectedItem as Meeting;

            lblTitle.Text = selectedMeeting.Title;
            lblDate.Text = selectedMeeting.Date.ToShortDateString();
            lblStartTime.Text = selectedMeeting.StartTime;
            lblEndTime.Text = selectedMeeting.EndTime;
            lblSubject.Text = selectedMeeting.Subject;

            var list = ps.getAllParticipantsByMeetingID(selectedMeeting.MeetingID);
            fLwParticipants.Controls.Clear();
            // Virtual Tools
            foreach (Participant item in list)
            {
                Panel pnl = new Panel();
                pnl.Size = new Size(74, 120);
                pnl.Margin = new Padding(5);
                PictureBox pb = new PictureBox();
                pb.Size = new Size(74, 70);
                pb.SizeMode = PictureBoxSizeMode.StretchImage;
                if (item.PhotoPath != null)
                    pb.Image = Image.FromFile(item.PhotoPath);

                pnl.Controls.Add(pb);

                Label lbl1 = new Label();
                lbl1.Font = new Font("Microsoft Sans Serif", 9);
                lbl1.Text = item.FullName;
                lbl1.Location = new Point(3, 73);
                lbl1.AutoSize = false;
                lbl1.Size = new Size(74, 15);
                lbl1.TextAlign = ContentAlignment.MiddleCenter;
                pnl.Controls.Add(lbl1);


                Label lbl2 = new Label();
                lbl2.Font = new Font("Microsoft Sans Serif", 7);
                lbl2.Text = item.Position;
                lbl2.Location = new Point(3, 97);
                lbl2.AutoSize = false;
                lbl2.Size = new Size(74, 15);
                lbl2.TextAlign = ContentAlignment.MiddleCenter;
                lbl2.ForeColor = Color.Gray;

                pnl.Controls.Add(lbl2);

                fLwParticipants.Controls.Add(pnl);
            }
        }
        // Timet Tick Event
        private void tmr_Tick(object sender, EventArgs e)
        {
            string yazi = lblInfo.Text;
            string ilkHarf = yazi.Substring(0, 1);
            yazi = yazi.Remove(0, 1);
            yazi += ilkHarf;
            lblInfo.Text = yazi;
        }
    }
}
