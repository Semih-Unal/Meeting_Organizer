namespace MO.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Meeting : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BridgeTables",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        MeetingID = c.Int(nullable: false),
                        ParticipantID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Meetings", t => t.MeetingID, cascadeDelete: true)
                .ForeignKey("dbo.Participants", t => t.ParticipantID, cascadeDelete: true)
                .Index(t => t.MeetingID)
                .Index(t => t.ParticipantID);
            
            CreateTable(
                "dbo.Meetings",
                c => new
                    {
                        MeetingID = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Subject = c.String(),
                        Date = c.DateTime(nullable: false),
                        StartTime = c.String(),
                        EndTime = c.String(),
                    })
                .PrimaryKey(t => t.MeetingID);
            
            CreateTable(
                "dbo.Participants",
                c => new
                    {
                        ParticipantID = c.Int(nullable: false, identity: true),
                        FullName = c.String(),
                        Position = c.String(),
                        PhotoPath = c.String(),
                    })
                .PrimaryKey(t => t.ParticipantID);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserID = c.Int(nullable: false, identity: true),
                        UserName = c.String(),
                        Password = c.String(),
                        FullName = c.String(),
                    })
                .PrimaryKey(t => t.UserID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BridgeTables", "ParticipantID", "dbo.Participants");
            DropForeignKey("dbo.BridgeTables", "MeetingID", "dbo.Meetings");
            DropIndex("dbo.BridgeTables", new[] { "ParticipantID" });
            DropIndex("dbo.BridgeTables", new[] { "MeetingID" });
            DropTable("dbo.Users");
            DropTable("dbo.Participants");
            DropTable("dbo.Meetings");
            DropTable("dbo.BridgeTables");
        }
    }
}
