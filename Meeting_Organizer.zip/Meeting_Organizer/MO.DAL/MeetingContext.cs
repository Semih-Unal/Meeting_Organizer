﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MO.DAL
{
    public class MeetingContext : DbContext
    {
        public MeetingContext() : base("name=cnn") { }

        public DbSet<Meeting> Meetings { get; set; }
        public DbSet<Participant> Participants { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<BridgeTable>  BridgeTables { get; set; }
    }
    [Table("Meetings")]
    public class Meeting
    {
        public Meeting()
        {
            this.Date = DateTime.Now;
            this.StartTime = DateTime.Now.ToShortTimeString();
            this.EndTime = DateTime.Now.ToShortTimeString();
            this.bridgeTable = new HashSet<BridgeTable>();
        }
        [Key]
        public int MeetingID { get; set; }
        public string Title { get; set; }
        public string Subject { get; set; }
        public DateTime Date { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        
        public ICollection<BridgeTable> bridgeTable { get; set; }
    }
    [Table("BridgeTables")]
    public class BridgeTable
    {
        [Key]
        public int ID { get; set; }
        public int MeetingID { get; set; }
        public int ParticipantID { get; set; }


        public virtual Meeting meeting { get; set; }

        public virtual Participant participant { get; set; }
    }

    [Table("Participants")]
    public class Participant
    {
        public Participant()
        {
            this.bridgeTable = new HashSet<BridgeTable>();
        }

        [Key]
        public int ParticipantID { get; set; }
        public string FullName { get; set; }
        public string Position { get; set; }
        public string PhotoPath { get; set; }

        public ICollection<BridgeTable> bridgeTable { get; set; }
    }
    [Table("Users")]
    public class User
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
    }
}
