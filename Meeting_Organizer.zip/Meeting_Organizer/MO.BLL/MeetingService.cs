﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MO.DAL;
namespace MO.BLL
{
    public class MeetingService
    {
        MeetingContext db = new MeetingContext();

        public List<Meeting> getAllMeetings()
        {
            return db.Meetings.ToList();
        }

        public List<Meeting> getMeetingsByDate(DateTime date)
        {
            List<Meeting> list = new List<Meeting>();

            foreach (Meeting meeting in db.Meetings.ToList())
            {
                if (meeting.Date.ToShortDateString() == date.ToShortDateString())
                {
                    list.Add(meeting);
                }
            }
            return list;
        }
        
        public Meeting getMeetingById(int ID)
        {
            return db.Meetings.FirstOrDefault(m=>m.MeetingID == ID);
        }

        public bool InsertMeeting(Meeting newMeeting)
        {
            bool result = false;
            try
            {
                db.Meetings.Add(newMeeting);

                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }

            return result;
        }
        public bool DeleteMeeting(int removeMeetingId)
        {
            bool result = false;
            try
            {
                var meeting = db.Meetings.FirstOrDefault(x => x.MeetingID == removeMeetingId);
                db.Meetings.Remove(meeting);

                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }

            return result;
        }
        public bool UpdateMeeting(Meeting updateMeeting)
        {
            bool result = false;
            try
            {
                Meeting meeting = db.Meetings.FirstOrDefault(m=>m.MeetingID == updateMeeting.MeetingID);
                meeting.Title = updateMeeting.Title;
                meeting.Subject = updateMeeting.Subject;
                meeting.StartTime = updateMeeting.StartTime;
                meeting.EndTime = updateMeeting.EndTime;
                meeting.Date = updateMeeting.Date;


                result = db.SaveChanges() > 0 ? true : false;
            }
            catch
            {

            }

            return result;
        }
    }
}
