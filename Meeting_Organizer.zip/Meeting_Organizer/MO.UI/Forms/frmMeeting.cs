﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MO.BLL;
using MO.DAL;

namespace MO.UI.Forms
{
    public partial class frmMeeting : Form
    {
        MeetingService ms = new MeetingService();
        ParticipantService ps = new ParticipantService();
        BridgeTableService bs = new BridgeTableService();
        int SelectedMeetingId;
        int SelectedParticipantId;

        public frmMeeting()
        {
            InitializeComponent();
        }

        private void frmMeeting_Load(object sender, EventArgs e)
        {
            FillMeeting();
            FillParticipants();
            tmr.Start();
            tabControl1.SelectedIndex = 0;
        }
        // Home button
        private void btnHome_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();

            frmHome.Show();
            this.Hide();
        }
        // Close Button
        private void btnClose_Click(object sender, EventArgs e)
        {
            Form1 frmHome = new Form1();
            frmHome.Show();
            this.Hide();
        }
        // Timer Tick Event
        private void tmr_Tick(object sender, EventArgs e)
        {
            lblLoginTime.Text = DateTime.Now.ToLongTimeString();
        }
        // TabControl Selected Event
        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPageIndex == 1)
            {
                if (SelectedMeetingId == 0)
                {
                    MessageBox.Show("Önce Bir Toplantı Seçiniz!!");

                    tabControl1.SelectedIndex = 0;
                }
            }
        }

        #region Meeting Page

        // List Method
        private void FillMeeting()
        {
            dGwMeetings.DataSource = ms.getAllMeetings();

            dGwMeetings.Columns[0].Visible = false;
            dGwMeetings.Columns[6].Visible = false;
        }
        // Add
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtMeetingName.Text == "" || txtMeetingSubject.Text == "" || mtxtEndTime.Text == "" || mtxtStartTime.Text == "")
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz!!");
                return;
            }
            Meeting meeting = new Meeting()
            {
                Title = txtMeetingName.Text,
                Subject = txtMeetingSubject.Text,
                Date = dTpDate.Value,
                EndTime = mtxtEndTime.Text,
                StartTime = mtxtStartTime.Text
            };

            if (ms.InsertMeeting(meeting) == true)
                MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
            else
                MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

            FillMeeting();

            FieldClear();
        }
        // Update
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtMeetingName.Text == "" || txtMeetingSubject.Text == "" || mtxtEndTime.Text == "" || mtxtStartTime.Text == "")
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz!!");
                return;
            }
            Meeting meeting = new Meeting()
            {
                MeetingID = SelectedMeetingId,
                Title = txtMeetingName.Text,
                Subject = txtMeetingSubject.Text,
                Date = dTpDate.Value,
                EndTime = mtxtEndTime.Text,
                StartTime = mtxtStartTime.Text
            };

            if (ms.UpdateMeeting(meeting) == true)
                MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
            else
                MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

            FillMeeting();

            FieldClear();
        }
        // Delete
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silmek istediğinize emin misiniz?", "Silme İşlemi", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (ms.DeleteMeeting(SelectedMeetingId) == true)
                    MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
                else
                    MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

                FillMeeting();

            }

            FieldClear();
        }
        //DataGridView CellClick Event
        private void dGwMeetings_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectedMeetingId = Convert.ToInt32(dGwMeetings.CurrentRow.Cells[0].Value);

            Meeting selectedMeeting = ms.getMeetingById(SelectedMeetingId);
            txtMeetingName.Text = selectedMeeting.Title;
            txtMeetingSubject.Text = selectedMeeting.Subject;
            dTpDate.Value = selectedMeeting.Date;
            mtxtEndTime.Text = selectedMeeting.EndTime;
            mtxtStartTime.Text = selectedMeeting.StartTime;


        }
        // Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            FieldClear();
        }

        // Clear Method
        private void FieldClear()
        {
            txtMeetingName.Text = "";
            txtMeetingSubject.Text = "";
            dTpDate.Value = DateTime.Now;
            mtxtEndTime.Clear();
            mtxtStartTime.Clear(); ;
        }

        #endregion

        #region Participant Page
        // List Method
        private void FillParticipants()
        {
            dGwParticipants.Rows.Clear();
            var list = ps.getAllParticipants();

            foreach (Participant item in list)
            {
                dGwParticipants.Rows.Add(false, item.FullName, item.Position, item.PhotoPath, item.ParticipantID);
            }
            dGwParticipants.Columns[4].Visible = false;
        }

        // File
        string filename = "";
        private void btnSelectPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(.jpg)|*.jpg|PNG(.png)|*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filename = ofd.FileName;

                pbPhoto.Image = Image.FromFile(filename);
                txtPhotoPath.Text = filename;
            }
        }
        // Add
        private void btnParticipantAdd_Click(object sender, EventArgs e)
        {
            if (txtFullName.Text == "" || txtPosition.Text == "" || txtPhotoPath.Text == "")
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz!!");
                return;
            }
            Participant participant = new Participant();

            participant.FullName = txtFullName.Text;
            participant.Position = txtPosition.Text;

            string Resim = txtPhotoPath.Text;
            if (File.Exists(Resim) == false)
            {
                Resim = @"..\..\Images\" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(filename);

                Image img = Image.FromFile(filename);

                img.Save(Resim);

            }
            participant.PhotoPath = Resim;

            if (ps.InsertParticipant(participant, SelectedMeetingId) == true)
                MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
            else
                MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

            FillParticipants();
            ParticipantFieldsClear();
        }
        // Update
        private void btnParticipantUpdate_Click(object sender, EventArgs e)
        {
            if (txtFullName.Text == "" || txtPosition.Text == "" || txtPhotoPath.Text == "")
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz!!");
                return;
            }
            if (SelectedMeetingId == 0)
            {
                MessageBox.Show("Lütfen Toplantı Seçiniz!!");
                return;
            }
            Participant participant = new Participant();

            participant.ParticipantID = SelectedParticipantId;
            participant.FullName = txtFullName.Text;
            participant.Position = txtPosition.Text;
            participant.PhotoPath = txtPhotoPath.Text;

            if (filename != "")
            {
                string Resim = @"..\..\Images\" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(filename);

                Image img = Image.FromFile(filename);

                img.Save(Resim);

                participant.PhotoPath = Resim;
            }

            if (ps.UpdateParticipant(participant, SelectedMeetingId) == true)
                MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
            else
                MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

            FillParticipants();
            ParticipantFieldsClear();
        }
        // Delete
        private void btnParticipantDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silmek istediğinize emin misiniz?", "Silme İşlemi", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (ps.DeleteParticipant(SelectedParticipantId) == true)
                    MessageBox.Show("İşleminiz Başarılıyla Gerçekleştirildi");
                else
                    MessageBox.Show("Beklenmedik Bir Hatayla Karşılaşıldı, Tekrar Deneyiniz.");

                FillParticipants();

            }
            ParticipantFieldsClear();
        }
        // DataGridView CellClick Event
        private void dGwParticipants_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectedParticipantId = Convert.ToInt32(dGwParticipants.CurrentRow.Cells[4].Value);

            Participant selectedParticipants = ps.getParticipantById(SelectedParticipantId);
            txtFullName.Text = selectedParticipants.FullName;
            txtPosition.Text = selectedParticipants.Position;
            txtPhotoPath.Text = selectedParticipants.PhotoPath;
            if (selectedParticipants.PhotoPath != null)
                pbPhoto.Image = Image.FromFile(selectedParticipants.PhotoPath);

        }
        // Add Meeting
        private void btnAddMeeting_Click(object sender, EventArgs e)
        {
            if (SelectedMeetingId == 0)
            {
                MessageBox.Show("Lütfen Toplantı Seçiniz!!");
                return;
            }
            List<BridgeTable> listBridge = new List<BridgeTable>();
            foreach (DataGridViewRow row in dGwParticipants.Rows)
            {
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];
                if (Convert.ToBoolean(chk.Value) == true)
                {
                    BridgeTable b = new BridgeTable();
                    b.MeetingID = SelectedMeetingId;
                    b.ParticipantID = Convert.ToInt32(row.Cells[4].Value);
                    bs.InsertBridge(b);
                }
            }
            ParticipantFieldsClear();
        }
        // Clear
        private void btnFieldClear_Click(object sender, EventArgs e)
        {
            ParticipantFieldsClear();
        }
        // Clear Method
        private void ParticipantFieldsClear()
        {
            txtFullName.Clear();
            txtPhotoPath.Clear();
            txtPosition.Clear();
            pbPhoto.Image = null;
        }
        #endregion
    }
}
